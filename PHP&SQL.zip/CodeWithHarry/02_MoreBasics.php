<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP TUTORIAL</title>
</head>
<style>
    *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    }

    .container{
    max-width: 80%;
    background-color: grey;
    display: block;
    margin: auto;
    padding: 23px;
    }
</style>
<body>
    <div class="container">
    <h1>Lets learn about php</h1>
    This is a container
    <p>your party status is here</p>
    <?php

    //    IF-ELSE statements
    $age = 34;
    if($age>18){
        echo "You can go to the party";
    }
    // else if(){}
    else{
        echo "You can not go to the party";
    }
    echo "<br>";
    
    //     ARRAYS
    $languages = array("Python", "C++", "php", "NodeJs");
    // echo $languages[0];  // this prints python
    // echo "<br>";
    // echo count($languages); // no of items
    
    //            LOOPS
    
    //   Iterating arrays in php using while loop
    $a = 0;
    while ($a < count($languages)){
        echo "<br>";
        echo $languages[$a] ;
        $a++;
    }

    // Do while loop 
    $a = 0;
    do {
        echo "<br>";
        echo $languages[$a] ;
        $a++;
    }while ($a < count($languages));
     
    //  For loop
    for ($b=0; $b< 10; $b++) { 
        echo $b;
    echo "<br>";
    }
    // Foreach
    foreach($languages as $value){
        echo "<br>The value from foreach loop is :";
        echo $value; echo "<br>";
    }

    //            FUNCTIONS 

    function print5(){
        echo "FIVE";
    }
    print5();

    $n = 5;
    function print_n($n){
        echo "Below no is x 4";
        echo "<br>";
        
        return $n*4;
    }
    $x = print_n($n);
    echo $x;

    function ss($n){
        echo $n;
    }
    ss(22);
    ss(23);
    ss(26);
    ?>
    </div>
</body>
</html>