<?php 

    $con = mysqli_connect("localhost", "root", "", "trip");

    if(!$con){
        die("Connection Error...");
    }

?>