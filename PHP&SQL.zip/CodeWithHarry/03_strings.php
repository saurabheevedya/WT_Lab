 <?php

//          STRINGS

$str = "This is a string";
echo $str; echo "<br>";
$l = strlen($str);
echo "length of string is ". $l . " THANK YOU";
// echo $l;
echo "<br>";
echo "No of words in string is ". str_word_count($str);
echo "<br>";
echo "reverse string is ". strrev($str);
echo "<br>";
echo "No position of word is ". strpos($str, "a");
echo "<br>";
echo " replaced words string is ". str_replace( "a", "the", $str);
echo "<br>";
echo $str;   // it ramains the same, no changes to original string

?>