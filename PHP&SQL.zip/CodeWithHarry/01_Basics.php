<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Tutorial</title>
</head>
<body>
<div class="container">
    This is my php website
    <br>
    <!-- <?php
    echo " \n Hollo World, This is printed using php";
    echo "<br>";
    ?> -->
      
    <?php
    define('PI', 3.14);
    echo " \n Hollo World AGAINN!!, This is printed using php";
    echo "<br>";
    $variable1 = 32;
    $variable2 = 45;
    echo $variable1;
    echo "<br>";
    echo $variable2;
    echo "<br>";
    
    echo $variable1 + $variable2 ;
    echo "<br>";

    //          OPERATORS IN PHP 

    // Arithmatic OPerators
    echo "The addition of these two variables is :" ;
    echo "<br>";
    ECHO $variable1 + $variable2;
    echo "<br>";
    ECHO $variable1 - $variable2;
    echo "<br>";
    ECHO $variable1 * $variable2;
    echo "<br>";
    ECHO $variable1 / $variable2;
    echo "<br>";

    // Assignment OPerators
    $newvar = $variable1;
    echo $newvar;
    echo "<br>";
    $newvar += 1;
    echo $newvar;
    echo "<br>";
    // can also use '*' and '/'

    // Comparison OPerators
    echo "<h3>Comparison Operators</h3>";
    echo "the value of 1==4 is";
    echo "<br>";
    echo var_dump(1==4);
    echo "<br>";

    // Increment/Decrement OPerators
    echo $variable1++;
    echo "<br>";
    echo $variable1--;
    echo "<br>";
    echo ++$variable1;
    echo "<br>";
    echo --$variable1;
    echo "<br>";

    // LOgical OPerators
    // and (&&)
    // or (||)
    // xor () , when one value is true and other is false, it returns bool(true), else it returns bool(false)
    // not (!)

    $myvar1 = (true && true);
    // csn also write (true and false)
    echo var_dump($myvar1);
    echo "<br>";
    $myvar2 = (true xor false);
    echo var_dump($myvar2);
    echo "<br>";
    $myvar3 = (true xor true);
    echo var_dump($myvar3);
    echo "<br>";
    $myvar4 = (false xor false);
    echo var_dump($myvar4);
    echo "<br>";

    //             DATA TYPES IN PHP
    // 1. String
    // 2. Integer
    // 3. Float
    // 4. Boolean
    // 5. Array 
    // 6. Object
    echo "<br> Data types in php <br>";
    $var = "This is a string";
    echo var_dump($var);
    echo "<br>";

    $var = 67;
    echo var_dump($var);
    echo "<br>";

    $var = 67.1;
    echo var_dump($var);
    echo "<br>";

    $var = true;
    echo var_dump($var);
    echo "<br>";
   
    //  const data type 
    echo PI;
    ?>
         
</div>
    
</body>
</html>